<?php // no direct access
defined('_JEXEC') or die('Restricted access');
$user = &JFactory::getUser();

?>

<div class="componentheading<?php echo $this->params->get('pageclass_sfx'); ?>">
	<?php $this->escape($this->params->get('page_title')); ?>
</div>

<form name="adminForm" method="post" action="<?php echo $this->action; ?>">

<table width="100%" cellpadding="3" cellspacing="3" border="1" id="table_frontend_user_article_list">
<thead>
	<tr>
		<td colspan="<?php echo $this->total_columns; ?>" align="left" valign="bottom">
			<div style="float:left;">
			<?php
			if ($this->params->get('showsearchfilter') == 1) {
			echo JText::_('COM_UAM_FILTER'); ?>:
			<br />
			<input id="filter_search" type="text" name="filter_search" value="<?php echo $this->escape($this->lists['filter_search']);?>" class="inputbox" /> 
			<button onclick="this.form.submit();"><?php echo JText::_('COM_UAM_GO'); ?></button>
			<button onclick="document.getElementById('filter_search').value=''; document.getElementById('filter_state').value=''; document.getElementById('filter_catid').value='0'; document.getElementById('filter_authorid').value='0'; this.form.submit();"><?php echo JText::_('COM_UAM_RESET'); ?></button>
			<?php
			}
			echo '<br />';
			$add_break = 0;
			if (($this->params->get('useallcategories') == 1) && ($this->params->get('showcategoryfilter') == 1)) {
				echo $this->lists['catid'];
				$add_break = 1;
			}
			if (($this->canEditOwnOnly == false) && ($this->params->get('showauthorfilter') == 1)) {
				echo $this->lists['authorid'];
				$add_break = 1;
			}
			if ($this->params->get('showpublishedstatefilter') == 1) {
				echo $this->lists['state'];
				$add_break = 1;
			}
			if ($add_break == 1) {
				echo '<br /><br />';
			}
			?>
			</div>

			<?php
			if($this->params->get('new_article_button')) {
				$custom_link = trim($this->params->get('link_new_article'));
				//default link
				if($this->params->get('link_new_article_default')
					|| (!$this->params->get('link_new_article_default') && strlen($custom_link) == 0)) {
						$uri =& JFactory::getURI();
						$ret = base64_encode($uri->toString());
						$link_new_article = JRoute::_("index.php?option=com_content&view=form&layout=edit&return=$ret");
				}
				else {//custom link
					$link_new_article = $custom_link;
				}
				?>
			<br />
			<button type="button" id="bt_new_article" onclick="location.href='<?php echo $link_new_article; ?>';">
					<img src="<?php echo 'components/com_uam/assets/images/ico_article_add.png'; ?>" alt="<?php echo JText::_('COM_UAM_NEW_ARTICLE'); ?>" />
					<?php echo JText::_('COM_UAM_NEW_ARTICLE'); ?>
				</button>
				<?php
			}
			?>
		</td>
	</tr>

	<tr>
		<?php
		if($this->params->get('id_column')) :
			?>
			<th style="" align="center">
				<?php echo JHTML::_('grid.sort', 'ID', 'c.id', $this->lists['order_Dir'], $this->lists['order']); ?>
			</th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('title_column')) :
			?>
			<th style="" align="center">
				<?php echo JHTML::_('grid.sort', 'COM_UAM_TITLE', 'c.title', $this->lists['order_Dir'], $this->lists['order']); ?>
			</th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('published_column')) :
			?>
			<th style="" align="center">
				<?php echo JHTML::_('grid.sort', 'COM_UAM_PUBLISHED_HEADING', 'c.state', $this->lists['order_Dir'], $this->lists['order']); ?>
			</th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('featured_column')) :
			?>
			<th style="" align="center">
				<?php echo JHTML::_('grid.sort', 'COM_UAM_FEATURED_HEADING', 'c.featured', $this->lists['order_Dir'], $this->lists['order']); ?>
			</th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('category_column')) :
			?>
			<th style="" align="center">
				<?php echo JHTML::_('grid.sort', 'COM_UAM_CATEGORY', 'category', $this->lists['order_Dir'], $this->lists['order']); ?>
			</th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('author_column')) :
			?>
			<th style="" align="center">
				<?php echo JHTML::_('grid.sort', 'COM_UAM_AUTHOR', 'author', $this->lists['order_Dir'], $this->lists['order']); ?>
			</th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('created_date_column')) :
			?>
			<th style="" align="center">
				<?php echo JHTML::_('grid.sort', 'COM_UAM_CREATED_DATE', 'c.created', $this->lists['order_Dir'], $this->lists['order']); ?>
			</th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('start_publishing_column')) :
			?>
			<th style="" align="center">
				<?php echo JHTML::_('grid.sort', 'COM_UAM_START_PUBLISHING', 'c.publish_up', $this->lists['order_Dir'], $this->lists['order']); ?>
			</th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('finish_publishing_column')) :
			?>
			<th style="" align="center">
				<?php echo JHTML::_('grid.sort', 'COM_UAM_FINISH_PUBLISHING', 'c.publish_down', $this->lists['order_Dir'], $this->lists['order']); ?>
			</th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('hits_column')) :
			?>
			<th style="" align="center">
				<?php echo JHTML::_('grid.sort', 'COM_UAM_HITS', 'c.hits', $this->lists['order_Dir'], $this->lists['order']); ?>
			</th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('edit_alias_column')) :
			?>
			<th style="" align="center"><?php echo JText::_('COM_UAM_EDIT_ALIAS'); ?></th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('copy_column')) :
			?>
			<th style="" align="center"><?php echo JText::_('COM_UAM_COPY'); ?></th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('edit_column')) :
			?>
			<th style="" align="center"><?php echo JText::_('COM_UAM_EDIT'); ?></th>
			<?php
		endif;
		?>
		<?php
		if($this->params->get('trash_column')) :
			?>
			<th style="" align="center"><?php echo JText::_('COM_UAM_TRASH'); ?></th>
			<?php
		endif;
		?>
	</tr>
</thead>
<tfoot>
	<tr>
		<td colspan="<?php echo $this->total_columns; ?>" align="center">
			<?php echo $this->pagination->getListFooter(); ?>
		</td>
	</tr>
</tfoot>
<tbody>

	<?php
	$count_itens = count($this->itens);

	//without article
	if(!$count_itens) { ?>
		<tr>
			<td colspan="<?php echo $this->total_columns; ?>" align="center">
				<?php echo JText::_('COM_UAM_NO_ARTICLES_FOUND'); ?>
			</td>
		</tr>
	<?php
	}
	else {
		$k = 0;
		for($i=0; $i < $count_itens; $i++) {
			$row = &$this->getItem($i, $this->params);

			$asset	= 'com_content.article.'.$row->id;
			$this->access->canCreate = $user->authorise('core.create', 'com_content.category.'.$row->catid);
			// Check general edit permission first.
			$this->access->canPublish = $user->authorise('core.edit.state', $asset);
			// Check general edit permission first.
			$this->access->canEdit = $user->authorise('core.edit', $asset);
			// Now check if edit.own is available.
			$this->access->canEditOwn = $user->authorise('core.edit.own', $asset) && ($this->user->id == $row->created_by);
			?>
	
			<tr class="<?php echo "fual_row$k"; ?>">
				<?php
				if($this->params->get('id_column')) :
					?>
					<td align="center">
						<?php echo $row->id; ?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('title_column')) :
					?>
					<td style="font-weight:bold;">
						<?php
						$title = htmlentities($row->introtext . $row->fulltext, ENT_COMPAT, "UTF-8");
						$link = JRoute::_(ContentHelperRoute::getArticleRoute($row->id, $row->catslug));
						if ($this->params->get('show_content')) {
							if($row->state > 0) {
								echo '<span class="hasTip" title="'.JText::_( $row->title ).' :: ' . $title . '"><a href=' . $link . '>' . $row->title . '</a></span>';
							}
							else {
								echo '<span class="hasTip" title="'.JText::_( $row->title ).' :: ' . $title . '">' . $row->title . '</span>';
							}
						}
						else {
							if($row->state > 0) {
								echo '<a href=' . $link . '>' . $row->title . '</a>';
							}
							else {
								echo $row->title;
							}
						}
						echo "<input type='hidden' id='fual_{$row->id}_title' value='{$row->title}' />";
						echo "<input type='hidden' id='fual_{$row->id}_alias' value='{$row->alias}' />";
						?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('published_column')) :
					?>
					<td align="center">
						<?php
							$override = false;

							if(($this->access->canEdit || $this->access->canEditOwn) && $this->params->get('user_can_publish'))
							{
								$override = true;
							}
							
							if(($this->access->canPublish && $row->state != -2) ||
								($this->user->id == $row->created_by && $override)) {
								
								$url = "index.php?option=com_uam&view=uam&task=unPublish&cid={$row->id}&Itemid=" . JRequest::getInt('Itemid');
								$link = JRoute::_($url);
								echo "<a href='$link'>";

								$img = $this->baseurl . "/components/com_uam/assets/images/";
								$img .= ($row->state > 0) ? "publish_g.png" : "publish_r.png";
								$alt = ($row->state > 0) ? JText::_('COM_UAM_PUBLISHED') : JText::_('COM_UAM_UNPUBLISHED');
							
								echo "<img src='$img' alt='$alt' title='$alt' />";
	
								echo '</a>';
							}
							else {
								$img = $this->baseurl . "/components/com_uam/assets/images/";
								$img .= ($row->state > 0) ? "bw_publish_g.png" : "bw_publish_r.png";
								$alt = ($row->state > 0) ? JText::_('COM_UAM_PUBLISHED') : JText::_('COM_UAM_UNPUBLISHED');
								echo "<img src='$img' alt='$alt' title='$alt' />";
							}
						?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('featured_column')) :
					?>
					<td align="center">
						<?php
							$override = false;

							if(($this->access->canEdit || $this->access->canEditOwn) && $this->params->get('user_can_feature'))
							{
								$override = true;
							}
							
							if(($this->access->canPublish && $row->state != -2) ||
								($this->user->id == $row->created_by && $override)) {
								
								$url = "index.php?option=com_uam&view=uam&task=unFeature&cid={$row->id}&Itemid=" . JRequest::getInt('Itemid');
								$link = JRoute::_($url);
								echo "<a href='$link'>";

								$img = $this->baseurl . "/components/com_uam/assets/images/";
								$img .= ($row->featured > 0) ? "ico_featured.png" : "ico_not_featured.png";
								$alt = ($row->featured > 0) ? JText::_('COM_UAM_FEATURED') : JText::_('COM_UAM_NOT_FEATURED');
							
								echo "<img src='$img' alt='$alt' title='$alt' />";
	
								echo '</a>';
							}
							else {
								$img = $this->baseurl . "/components/com_uam/assets/images/";
								$img .= ($row->featured > 0) ? "bw_ico_featured.png" : "bw_ico_not_featured.png";
								$alt = ($row->state > 0) ? JText::_('COM_UAM_FEATURED') : JText::_('COM_UAM_NOT_FEATURED');
								echo "<img src='$img' alt='$alt' title='$alt' />";
							}
						?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('category_column')) :
					?>
					<td>
						<a href="<?php echo ContentHelperRoute::getCategoryRoute($row->catid); ?>" style="font-weight:normal;">
							<?php echo $row->category; ?>
						</a>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('author_column')) :
					?>
					<td>
						<?php
						if(strlen(trim($row->created_by_alias))) {
							echo $row->created_by_alias;
							echo "<br />({$row->author})";
						}
						else {
							echo $row->author;
						}
						?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('created_date_column')) :
					?>
					<td align="center">
						<?php echo JHTML::_('date', $row->created, JText::_('DATE_FORMAT_LC4')); ?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('start_publishing_column')) :
					?>
					<td align="center">
						<?php echo JHTML::_('date', $row->publish_up, JText::_('DATE_FORMAT_LC4')); ?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('finish_publishing_column')) :
					?>
					<td align="center">
						<?php
						if($row->publish_down == '0000-00-00 00:00:00') {
							echo JText::_('COM_UAM_NEVER');
						}
						else {
							echo JHTML::_('date', $row->publish_down, JText::_('DATE_FORMAT_LC4'));
						}
						?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('hits_column')) :
					?>
					<td align="center">
						<?php echo $row->hits; ?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('edit_alias_column')) :
					?>
					<td align="center">
						<?php
						if($row->state != -2 && ($this->access->canEdit || $this->access->canEditOwn)) {
							$img = $this->baseurl . "/components/com_uam/assets/images/ico_alias.png";
							$alt = JText::_('COM_UAM_EDIT_ALIAS');
							$title = $alt . ' :: ' . $row->alias;
							echo "<a href='javascript:void(0);' onclick='fualEditAlias({$row->id},event);'>";
							echo "<img src='$img' alt='$alt' title='$title' class='lhasTip' id='img_alias_{$row->id}' />";
							echo "<a/>";
						}
						else {
							$img = $this->baseurl . "/components/com_uam/assets/images/bw_ico_alias.png";
							$alt = JText::_('COM_UAM_EDIT_ALIAS');
							$title = $alt . ' :: ' . $row->alias;
							echo "<img src='$img' alt='$alt' title='$title' class='lhasTip' id='img_alias_{$row->id}' />";
						}
						?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('copy_column')) :
					?>
					<td align="center">
						<?php
						if($row->state != -2) {
							$text = JHTML::_('image.site', 'ico_copy.png', '/components/com_uam/assets/images/', NULL, NULL, JText::_('Copy'));
							$url = "index.php?option=com_uam&controller=&task=copy&cid={$row->id}&Itemid=" . JRequest::getInt('Itemid');
							$msg_confirm = JText::_('COM_UAM_WOULD_YOU_LIKE_TO_CREATE_AN_ARTICLE_COPY', true);
							$attr = array('onclick'=>"if(!confirm('$msg_confirm')) { return false; }",
									"title"=>JText::_('COM_UAM_CREATE_A_COPY'));
							echo JHTML::_('link', JRoute::_($url), $text, $attr);
						}
						?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('edit_column')) :
					?>
					<td align="center">
						<?php
							echo $this->getEditIcon($row, $row->params, $this->access);
						?>
					</td>
					<?php
				endif;
				?>
				<?php
				if($this->params->get('trash_column')) :
					?>
					<td align="center">
						<?php
						$override = false;

						if(($this->access->canEdit || $this->access->canEditOwn) && $this->params->get('user_can_trash'))
						{
							$override = true;
						}
							
						if($this->access->canPublish || ($this->user->id == $row->created_by && $override))
						{
							if($row->state == -2) {
								$msg_confirm = JText::_('COM_UAM_RESTORE_CONFIRM', true);
								$img = $this->baseurl . "/components/com_uam/assets/images/ico_restore.png";
								$alt = JText::_('COM_UAM_RESTORE_FROM_TRASH');
							}
							else {
								$msg_confirm = JText::_('COM_UAM_TRASH_CONFIRM', true);
								$img = $this->baseurl . "/components/com_uam/assets/images/ico_trash.png";
								$alt = JText::_('COM_UAM_MOVE_TO_TRASH');
							}
							$link = JRoute::_("index.php?option=com_uam&controller=&task=trash&cid={$row->id}&Itemid=" . JRequest::getInt('Itemid'));

							echo "<a href='$link' onclick=\"if(!confirm('$msg_confirm')) { return false; }\">";
							echo "<img src='$img' alt='$alt' title='$alt' />";
							echo "</a>";
						}
						else {
							if($row->state == -2) {
								$msg_confirm = JText::_('COM_UAM_RESTORE_CONFIRM', true);
								$img = $this->baseurl . "/components/com_uam/assets/images/bw_ico_restore.png";
								$alt = JText::_('COM_UAM_RESTORE_FROM_TRASH');
							}
							else {
								$msg_confirm = JText::_('COM_UAM_TRASH_CONFIRM', true);
								$img = $this->baseurl . "/components/com_uam/assets/images/bw_ico_trash.png";
								$alt = JText::_('COM_UAM_MOVE_TO_TRASH');
							}
							$link = JRoute::_("index.php?option=com_uam&controller=&task=trash&cid={$row->id}&Itemid=" . JRequest::getInt('Itemid'));

							echo "<img src='$img' alt='$alt' title='$alt' />";
						}
						?>
					</td>
					<?php
				endif;
				?>
			</tr>
			
			<?php
			$k = 1 - $k;
		}
	}
	?>

</tbody>
</table>

<input type="hidden" name="option" value="com_uam" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="uam" />
<input type="hidden" name="controller" value="" />
<input type="hidden" name="Itemid" value="<?php echo JRequest::getInt('Itemid'); ?>" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />

<?php echo JHTML::_('form.token'); ?>
</form>

<?php
//load template form edit alias
echo $this->loadTemplate('edit_alias');
?>
