ALTER TABLE
	`#__udjacomments`
CHARACTER SET utf8;